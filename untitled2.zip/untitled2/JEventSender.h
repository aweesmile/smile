#ifndef JEVENTSENDER_H
#define JEVENTSENDER_H

#include <QObject>
#include <QQmlEngine>
#include <QDebug>


class EventSender : public QObject
{
    Q_OBJECT
public:
    static QObject *qmlInstance (QQmlEngine *engine,QJSEngine *sctEngine)
    {
        (void) engine;
        (void) sctEngine;
        return getInstance();
    }
    static EventSender *getInstance()
    {
        static EventSender s_instance;
        return &s_instance;
    }
    Q_INVOKABLE void SendEvent(QString event)
    {
        qDebug() << "SendEvent:"<<event;
    }
private:
    explicit EventSender(QObject *parent = nullptr)
        :QObject (parent)
    {}

};
#endif // JEVENTSENDER_H
