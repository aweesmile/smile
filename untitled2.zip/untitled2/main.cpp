#include <QGuiApplication>
#include <QQmlApplicationEngine>
#include <QtQuick/QQuickView>
#include <QtCore/QDir>
#include <QtQml/QQmlEngine>
#include "JEventSender.h"
int main(int argc, char *argv[])
{
#if QT_VERSION < QT_VERSION_CHECK(6, 0, 0)
    QCoreApplication::setAttribute(Qt::AA_EnableHighDpiScaling);
#endif

    QGuiApplication app(argc, argv);
    //将EventSender注册到qml
    qmlRegisterSingletonType<EventSender>("EventSender",1,0,"EventSender",EventSender::qmlInstance);


    QQmlApplicationEngine engine;
    QQuickView* view = new QQuickView();
    const QUrl url(QStringLiteral("qrc:/Behavior1.qml"));
    QObject::connect(&engine, &QQmlApplicationEngine::objectCreated,
                     &app, [url](QObject *obj, const QUrl &objUrl) {
        if (!obj && url == objUrl)
            QCoreApplication::exit(-1);
    }, Qt::QueuedConnection);
    engine.load(url);



QObject::connect( (view->engine()), &QQmlEngine::quit,  view, &QWindow::close);


    view->setSource(url);
    view->setResizeMode(QQuickView::SizeRootObjectToView);//高分屏适配，自适应dpi
    //view->show();

    QQuickView* view1 = new QQuickView();

    //view1->setSource(QStringLiteral("qrc:/view1.qml"));
   // view1->show();

    return app.exec();
}
